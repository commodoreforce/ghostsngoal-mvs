Ghosts n Goals MVS - Level 1 R1 / Visual Revision 3

Richiede MAME. Controlli: 5 moneta, 1 Start, frecce movimento, Ctrl salto, Alt tiro.
Avvio dalla cartella estratta:
mame neogeo -cart1 gngl1r1 -hashpath . -rompath . -skip_gameinfo -window

Il BIOS libero ngdevkit incluso ha hash diversi dai BIOS SNK attesi da MAME: gli avvisi
su sp-s2.sp1, sm1.sm1 e sfix.sfix riguardano questo BIOS, non la cartuccia verificata.
Sorgenti: https://github.com/commodoreforce/ghostsngoal-mvs
SDK e BIOS: https://github.com/dciabrin/ngdevkit
