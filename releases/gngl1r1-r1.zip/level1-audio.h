// Generated from pinned web TRACKS at MVS video/audio clock rates.
#define GNG_LEVEL_LOOP_FRAMES 757
#define GNG_BOSS_LOOP_FRAMES 676
#define GNG_BOOST_LOOP_FRAMES 658
#define GNG_INTRO_FRAMES 2341
